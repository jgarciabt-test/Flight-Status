package com.airportstatus.entities;

public class Rating {

	private String late15;
	private String late30;
	private String late45;
	private String cancelled;
	private String diverted;
	
	public Rating(){
		
	}

	public String getLate15() {
		return late15;
	}

	public void setLate15(String late15) {
		this.late15 = late15;
	}

	public String getLate30() {
		return late30;
	}

	public void setLate30(String late30) {
		this.late30 = late30;
	}

	public String getLate45() {
		return late45;
	}

	public void setLate45(String late45) {
		this.late45 = late45;
	}

	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	public String getDiverted() {
		return diverted;
	}

	public void setDiverted(String diverted) {
		this.diverted = diverted;
	}
	
	
	
}
